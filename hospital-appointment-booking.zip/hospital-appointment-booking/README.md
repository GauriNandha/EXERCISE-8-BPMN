# Hospital Appointment Booking

Camunda 8.9 SaaS + Spring Boot 3.5.6 + Java 17.

## Configure credentials
Set environment variables before running. Do not commit API secrets:
- `CAMUNDA_CLIENT_ID`
- `CAMUNDA_CLIENT_SECRET`
- `CAMUNDA_CLUSTER_ID`
- `CAMUNDA_CLUSTER_REGION` (for example `sin-1`)

PowerShell:
```powershell
$env:CAMUNDA_CLIENT_ID="YOUR_CLIENT_ID"
$env:CAMUNDA_CLIENT_SECRET="YOUR_CLIENT_SECRET"
$env:CAMUNDA_CLUSTER_ID="YOUR_CLUSTER_ID"
$env:CAMUNDA_CLUSTER_REGION="sin-1"
mvn clean test
mvn spring-boot:run
```

## API
`POST http://localhost:8080/booking` starts `Hospital Appointment Booking` (`hospital-appointment`).

**Important:** deployment and local unit tests do not replace the required SaaS demonstration. After deploying, verify the process in Operate, complete any user task in Tasklist, and capture your own screenshots. Telegram connector credentials must be configured in Camunda Secrets as documented in the assignment.
