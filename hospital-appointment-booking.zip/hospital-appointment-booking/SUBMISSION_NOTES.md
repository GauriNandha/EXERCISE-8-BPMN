# Submission checklist — Hospital Appointment Booking

- Child process ID: `send-notification`; message inputs: `recipientId`, `messageText`.
- Parent process ID: `hospital-appointment`.
- DMN ID: `slot_decision`; hit policy: `UNIQUE`; inputs `department` and `bookedCount`; outputs `slotStatus`, `suggestedAction`.
- Cardiology with bookedCount >= 10 returns FULL.
- Parent invokes notification child process using call activities.
- Event subprocess `Handle cancellation` uses a non-interrupting message start correlated by `patientId`, releases slot, then invokes notification child.
- REST outbound connector uses the secret `TELEGRAM_BOT_TOKEN` in Camunda Secrets.

## Required live tests
1. POST `/booking` with Cardiology and bookedCount 3.
2. POST `/booking` with Cardiology and bookedCount 12.
3. Start a successful booking and publish a cancellation message with the same `patientId`.
4. Capture Operate screenshots showing parent, child instance link, and cancellation event-subprocess path.

The Camunda REST outbound connector must be available in the cluster and the `TELEGRAM_BOT_TOKEN` secret must be configured in the cluster before Telegram delivery can work. Replace/verify the connector template inputs in Web Modeler if your installed connector version uses a different template schema.
