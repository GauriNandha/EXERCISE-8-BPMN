package edu.srmist.hospital;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DecisionRulesTest {
    @Test void cardiologyAtTenIsFull() {
        assertTrue("Cardiology".equals("Cardiology") && 10 >= 10);
    }
    @Test void cardiologyBelowTenIsAvailable() {
        assertTrue(3 < 10);
    }
}
