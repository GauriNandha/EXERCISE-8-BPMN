package edu.srmist.hospital.api;

import io.camunda.client.CamundaClient;
import io.camunda.client.api.response.ProcessInstanceEvent;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
public class BookingController {
    private final CamundaClient client;
    public BookingController(CamundaClient client) { this.client = client; }

    @PostMapping("/booking")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public Map<String,Object> book(@RequestBody Map<String,Object> body) {
        ProcessInstanceEvent event = client.newCreateInstanceCommand()
            .bpmnProcessId("hospital-appointment").latestVersion()
            .variables(body).send().join();
        return Map.of("processInstanceKey", event.getProcessInstanceKey(),
                      "processId", "hospital-appointment");
    }
}
