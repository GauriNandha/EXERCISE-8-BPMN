package edu.srmist.hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import io.camunda.spring.client.annotation.Deployment;

@SpringBootApplication
@Deployment(resources = {
    "classpath:bpmn/hospital-appointment.bpmn",
    "classpath:bpmn/send-notification.bpmn",
    "classpath:dmn/slot_decision.dmn",
    "classpath:forms/booking.form"
})
public class HospitalBookingApplication {
    public static void main(String[] args) {
        SpringApplication.run(HospitalBookingApplication.class, args);
    }
}
