package edu.srmist.hospital.worker;

import io.camunda.client.annotation.JobWorker;
import io.camunda.client.annotation.Variable;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class NotificationWorker {
    private static final Logger log = LoggerFactory.getLogger(NotificationWorker.class);

    @JobWorker(type = "release-slot")
    public Map<String,Object> releaseSlot(@Variable String department,
                                          @Variable String patientId) {
        log.info("Released appointment slot for patient {} in {}", patientId, department);
        return Map.of("slotReleased", true);
    }

    // Optional local fallback worker. The primary assignment design uses the Camunda REST Outbound Connector.
    @JobWorker(type = "send-telegram-fallback")
    public void sendTelegramFallback(@Variable String recipientId,
                                     @Variable String messageText) throws Exception {
        String token = System.getenv("TELEGRAM_BOT_TOKEN");
        if (token == null || token.isBlank()) {
            log.warn("Telegram token is not configured; simulated notification to {}: {}", recipientId, messageText);
            return;
        }
        String body = "chat_id=" + URLEncoder.encode(recipientId, StandardCharsets.UTF_8)
            + "&text=" + URLEncoder.encode(messageText, StandardCharsets.UTF_8);
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://api.telegram.org/bot" + token + "/sendMessage"))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .POST(HttpRequest.BodyPublishers.ofString(body)).build();
        HttpResponse<String> response = HttpClient.newHttpClient()
            .send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() / 100 != 2) {
            throw new IllegalStateException("Telegram API failed: HTTP " + response.statusCode());
        }
        log.info("Telegram notification sent to {}", recipientId);
    }
}
